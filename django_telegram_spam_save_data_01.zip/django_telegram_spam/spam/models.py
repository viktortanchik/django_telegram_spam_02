from django.db import models
from django import forms
import time
#from django.contrib.auth.models import User
from django.conf import settings
from django.db import models
from django.contrib.auth import get_user_model,get_user
from django.conf import settings  # new

from django.dispatch import receiver
from django.db.models.signals import post_save, pre_save


User = get_user_model()


class User_settings(models.Model):
    #user = models.OneToOneField(User, on_delete=models.CASCADE)# work !!!

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    balance = models.CharField(max_length=100,default='test balance')
    wallet = models.CharField(max_length=100,default='test wallet')
    text = models.CharField(max_length=20,default='test TEXT')
    user_names = models.CharField(max_length=20,default='test user_names')
    tarif = models.CharField(max_length=20,default='test tarif')
    nambers = models.CharField(max_length=20,default='test nambers')

    def __str__(self):
        return self.user.username

class Subscriber(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE,blank=True,null=True)#,default=User)# related_name='user_names'

    texts = models.TextField(blank=True)
    TYPE_SELECT = (
        ('0', 'Indonesia account 1'),
        ('1', 'Vietnam account'),
        ('2', 'Indonesia account 2'),
    )
    gender = models.CharField(max_length=20, choices=TYPE_SELECT,blank=False,default=1)
    contact = models.CharField(max_length=128,blank=True)

    Main_Img = models.ImageField(upload_to='images/',blank=True)
    #user = models.OneToOneField(User, on_delete=models.CASCADE,default=User)

    #user = models.OneToOneField(User, on_delete=models.CASCADE,default=User)
    print(f'User---->>>>{User.username}')#user.username



    #user = models.OneToOneField(User, on_delete=models.CASCADE,default=request.user.is_authenticated)



    def __str__(self):
        return self.user.username


# @receiver(post_save, sender=settings.)
# def change_activity_status(sender, instance,created, **kwargs):
#     """ Signal to activate the profile (if the email and phone number are confirmed) """
#     if created:
#
#         Subscriber.objects.created(user=instance)
#         print('test_OK')
#     print('TEST SIGNALS')

    #user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='Scripts', blank=False,default=settings.AUTH_USER_MODEL)



    #user = models.ManyToManyField(User, on_delete=models.CASCADE,default=User)

    # def __str__(self):
    #     return self.user.username

    #
    # def __str__(self):
    #     #return f'{[self.adress, self.amount, self.text_mess]!r}'
    #     return f'{[self.texts,self.gender,self.gender,self.contact,self.Main_Img]!r}'


if __name__ == '__main__':
    Subscriber()