#from .forms import SubscriberForm#,ExampleForm
from .models import Subscriber
from .tg.tg import telega
import asyncio

from .forms import *
from django.http import HttpResponse
from django.shortcuts import render, redirect
##################################################
from django.http import HttpResponse
from django.contrib.auth import authenticate, login
from .forms import LoginForm
from .forms import LoginForm, UserRegistrationForm
from django.contrib.auth.views import LogoutView,auth_logout
from django.contrib.auth import logout
from django.views.generic.edit import CreateView
from django.contrib.auth.decorators import login_required

#sudo fuser -k 8000/tcp

##################################################

# Create your views here.
# def hotel_image_view(request):
#     form = HotelForm(request.POST, request.FILES)
#     if request.method == 'POST':
#         if form.is_valid():
#             #pass
#             form.save()
#             #return redirect('success')
#     else:
#         #pass
#         form = HotelForm()
#     #return render(request, 'spam/hotel_image_form.html', {'form': form})
#     return render(request,'spam/hotel_image_form.html', locals())

# def user_s(request):
#     return request.user.username
def success(request):
    return HttpResponse('successfully uploaded')


def index(request):
    #form = SubscriberForm(request.POST or None, request.FILES)  # OK
    #radio=ExampleForm(request.POST or None)
    form = SubscriberForm(request.POST, request.FILES)
    if request.user.is_authenticated:
        if request.method == "POST":

            filename = request.FILES
            #print(f'filename>>{filename}')
            #print(f'request.POST>>{request.POST}')
            data = request.POST
            # test_data = form.save()
            # print(f'test_data>>>>{test_data}')
            print(f'form>>>>>>>{request.user.username }')
            #print(f'DATA {data["texts"]}  contact>>{data["contact"]} hotel_Main_Img>>{data["Main_Img"]}')
            #print(f'DATA<<<<>>>>>>>{form.files}')
            #print(f'DATA<<<<>>>>>>>{form.auto_id}')

            #form.save()
            post = form.save(commit=False)
            post.user = request.user

            post.save()

            asyncio.run(telega(data["texts"], data["gender"], data["contact"]))

        #form = SubscriberForm()
        #return render(request,'spam/index.html', locals())
        return render(request,'base.html', locals())
        #return render(request, 'base.html', {'form': form})
    else:
        #form = LoginForm(request.POST)
        #form = LoginForm()

        print('login>>>')
        #return render(user_login,  locals())
        return redirect('/login')
        #return HttpResponse('Invalid login')

    #form = SubscriberForm(request.POST)


def user_login(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            cd = form.cleaned_data
            user = authenticate(username=cd['username'], password=cd['password'])
            if user is not None:
                if user.is_active:
                    login(request, user)
                    #return HttpResponse('Authenticated successfully')
                    #return render(request, 'spam/index.html', {'form': form})
                    #return render(request, 'base.html', {'form': form})
                    return redirect('/')
                    #return render(request, 'login.html', {'form': form})

                else:
                    return HttpResponse('Disabled account')
            else:
                return HttpResponse('Invalid login')
    else:
        form = LoginForm()

    return render(request, 'account/login.html', {'form': form})



def logout_view(request):
    logout(request)
    return redirect('/')
    #return render(request,'base.html', locals())


def register(request):
    if request.method == 'POST':
        user_form = UserRegistrationForm(request.POST)
        #form = SubscriberForm_test() # ТО что я хочу что бы создалосб в момент регистрации
        if user_form.is_valid():
            print(f"user_form>>>>>>>>{user_form}")
            # Create a new user object but avoid saving it yet
            new_user = user_form.save(commit=False)
            # Set the chosen password
            new_user.set_password(user_form.cleaned_data['password'])
            # Save the User object
            new_user.save()
            # form.is_valid()
            # form.save() # В момент сохранения выбивает ошибку


            return render(request, 'account/register_done.html', {'new_user': new_user})
    else:
        user_form = UserRegistrationForm()
    return render(request, 'account/register.html', {'user_form': user_form})